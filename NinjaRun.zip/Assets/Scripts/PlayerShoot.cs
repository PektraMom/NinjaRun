using UnityEngine;

public class PlayerShoot : MonoBehaviour
{
    [SerializeField] float attackCooldown;
    [SerializeField] Transform shurikenPoint;
    [SerializeField] GameObject[] shurikens;
    private Animator anim;
    private PlayerMovement playerMovement;
    private float cooldownTimer = Mathf.Infinity;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        playerMovement = GetComponent<PlayerMovement>();   

    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E) && cooldownTimer > attackCooldown && playerMovement.canShoot())
        {
            ShootShuriken();

            cooldownTimer += Time.deltaTime;
        }
    }

    private void ShootShuriken()
    {
        anim.SetTrigger("Shoot");
        cooldownTimer = 0;

        // Pool shurikens
        shurikens[FindShuriken()].transform.position = shurikenPoint.position;
        shurikens[FindShuriken()].GetComponent<Shuriken>().SetDirection(Mathf.Sign(transform.localScale.x));
    }

    private int FindShuriken()
    {
        for (int i = 0; i < shurikens.Length; i++)
        {
            if (!shurikens[i].activeInHierarchy)
            {
                return i;
            }
        }
        return 0;
    }
}
